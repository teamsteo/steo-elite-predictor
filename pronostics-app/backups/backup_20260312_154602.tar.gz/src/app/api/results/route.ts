import { NextResponse } from 'next/server';
import PredictionStore from '@/lib/store';

// Configuration GitHub
const GITHUB_REPO = 'steohidy/my-project';
const GITHUB_BRANCH = 'master';

/**
 * Charger les stats historiques depuis GitHub
 */
async function loadStatsHistory(): Promise<any> {
  try {
    const res = await fetch(
      `https://raw.githubusercontent.com/${GITHUB_REPO}/${GITHUB_BRANCH}/data/stats_history.json`,
      { next: { revalidate: 60 } }
    );
    if (res.ok) {
      return await res.json();
    }
  } catch (e) {
    console.error('Erreur chargement stats_history:', e);
  }
  return null;
}

/**
 * Charger les prédictions depuis GitHub
 */
async function loadPredictions(): Promise<any> {
  try {
    const res = await fetch(
      `https://raw.githubusercontent.com/${GITHUB_REPO}/${GITHUB_BRANCH}/data/predictions.json`,
      { next: { revalidate: 60 } }
    );
    if (res.ok) {
      return await res.json();
    }
  } catch (e) {
    console.error('Erreur chargement predictions:', e);
  }
  return null;
}

/**
 * Helper functions pour le filtrage temporel
 */
function isToday(dateString: string): boolean {
  const date = new Date(dateString);
  const today = new Date();
  return date.toDateString() === today.toDateString();
}

function isThisWeek(dateString: string): boolean {
  const date = new Date(dateString);
  const today = new Date();
  const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
  return date >= weekAgo && date <= today;
}

function isThisMonth(dateString: string): boolean {
  const date = new Date(dateString);
  const today = new Date();
  return date.getMonth() === today.getMonth() && date.getFullYear() === today.getFullYear();
}

function calculatePeriodStats(predictions: any[]): any {
  const total = predictions.length;
  const won = predictions.filter(p => p.result === 'win').length;
  const lost = predictions.filter(p => p.result === 'loss').length;
  const pending = predictions.filter(p => !p.result).length;
  
  const profit = predictions.reduce((sum, p) => {
    if (p.result === 'win') return sum + (p.stake || 10) * ((p.oddsHome || 1.85) - 1);
    if (p.result === 'loss') return sum - (p.stake || 10);
    return sum;
  }, 0);
  
  return {
    total,
    won,
    lost,
    pending,
    winRate: total > 0 ? Math.round((won / total) * 100) : 0,
    profit: Math.round(profit * 100) / 100,
    avgOdds: total > 0 ? predictions.reduce((sum, p) => sum + (p.oddsHome || 1.85), 0) / total : 0,
  };
}

/**
 * Calculer les stats depuis stats_history.json
 */
function calculateStatsFromHistory(statsHistory: any, predictions: any): any {
  if (!statsHistory || !statsHistory.dailyStats) {
    return null;
  }
  
  const dailyStats = statsHistory.dailyStats;
  const today = new Date().toISOString().split('T')[0];
  
  // Hier
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayStr = yesterday.toISOString().split('T')[0];
  
  const yesterdayData = dailyStats.find((d: any) => d.date === yesterdayStr);
  
  // Semaine (7 derniers jours)
  const weekAgo = new Date();
  weekAgo.setDate(weekAgo.getDate() - 7);
  const weekStats = dailyStats.filter((d: any) => new Date(d.date) >= weekAgo);
  
  // Mois (30 derniers jours)
  const monthAgo = new Date();
  monthAgo.setDate(monthAgo.getDate() - 30);
  const monthStats = dailyStats.filter((d: any) => new Date(d.date) >= monthAgo);
  
  // Calculer les agrégats depuis la structure réelle du fichier
  const aggregateStats = (stats: any[]) => {
    if (stats.length === 0) return { totalPredictions: 0, wins: 0, losses: 0, winRate: 0, completed: 0 };
    const totals = stats.reduce((acc, d) => ({
      completed: acc.completed + (d.stats?.completed || 0),
      wins: acc.wins + (d.stats?.wins || 0),
      losses: acc.losses + (d.stats?.losses || 0)
    }), { completed: 0, wins: 0, losses: 0 });
    
    return {
      totalPredictions: totals.completed,
      completed: totals.completed,
      wins: totals.wins,
      losses: totals.losses,
      winRate: totals.completed > 0 ? Math.round((totals.wins / totals.completed) * 100) : 0
    };
  };
  
  // Stats quotidiennes (hier)
  const dailyResult = yesterdayData ? {
    totalPredictions: yesterdayData.stats?.completed || 0,
    completed: yesterdayData.stats?.completed || 0,
    wins: yesterdayData.stats?.wins || 0,
    losses: yesterdayData.stats?.losses || 0,
    winRate: yesterdayData.stats?.winRate || 0,
    predictions: yesterdayData.predictions || []
  } : { totalPredictions: 0, completed: 0, wins: 0, losses: 0, winRate: 0, predictions: [] };
  
  return {
    daily: dailyResult,
    weekly: aggregateStats(weekStats),
    monthly: aggregateStats(monthStats),
    overall: statsHistory.summary || aggregateStats(dailyStats)
  };
}

/**
 * Normaliser le nom d'équipe pour la comparaison
 */
function normalizeTeamName(name: string): string {
  return name
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]/g, '')
    .substring(0, 8);
}

/**
 * Trouver le résultat correspondant dans les données Football-Data
 */
function findMatchResult(
  fdMatch: any, 
  homeTeam: string,
  awayTeam: string
): { found: boolean; homeScore: number; awayScore: number } {
  const predHomeNorm = normalizeTeamName(homeTeam);
  const predAwayNorm = normalizeTeamName(awayTeam);
  
  const fdHomeNorm = normalizeTeamName(fdMatch.homeTeam?.name || '');
  const fdAwayNorm = normalizeTeamName(fdMatch.awayTeam?.name || '');
  
  const homeMatch = predHomeNorm === fdHomeNorm || 
                    predHomeNorm.includes(fdHomeNorm) || 
                    fdHomeNorm.includes(predHomeNorm);
  const awayMatch = predAwayNorm === fdAwayNorm || 
                    predAwayNorm.includes(fdAwayNorm) || 
                    fdAwayNorm.includes(predAwayNorm);
  
  if (homeMatch && awayMatch) {
    return {
      found: true,
      homeScore: fdMatch.score?.fullTime?.home ?? fdMatch.score?.fullTime?.homeTeam ?? 0,
      awayScore: fdMatch.score?.fullTime?.away ?? fdMatch.score?.fullTime?.awayTeam ?? 0
    };
  }
  
  return { found: false, homeScore: 0, awayScore: 0 };
}

/**
 * Récupérer les résultats réels d'hier via Football-Data API
 */
async function fetchYesterdayResults(): Promise<any[]> {
  const apiKey = process.env.FOOTBALL_DATA_API_KEY;
  
  if (!apiKey) {
    console.error('❌ FOOTBALL_DATA_API_KEY non configurée');
    return [];
  }
  
  try {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const dateStr = yesterday.toISOString().split('T')[0];
    
    console.log(`📅 Récupération des résultats du ${dateStr}`);
    
    const response = await fetch(
      `https://api.football-data.org/v4/matches?date=${dateStr}`,
      {
        headers: { 'X-Auth-Token': apiKey },
        next: { revalidate: 0 }
      }
    );
    
    if (!response.ok) {
      console.error(`Erreur API Football-Data: ${response.status}`);
      return [];
    }
    
    const data = await response.json();
    
    const finishedMatches = (data.matches || []).filter(
      (m: any) => m.status === 'FINISHED' || m.status === 'FT'
    );
    
    console.log(`✅ ${finishedMatches.length} matchs terminés trouvés`);
    
    return finishedMatches;
    
  } catch (error) {
    console.error('Erreur récupération résultats:', error);
    return [];
  }
}

/**
 * GET - Récupérer les statistiques et pronostics
 */
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const action = searchParams.get('action') || 'stats';
    const sport = searchParams.get('sport'); // Filtre par sport
    const betType = searchParams.get('betType'); // Filtre par type de pari
    
    // Statistiques détaillées par période - DEPUIS GITHUB
    if (action === 'stats') {
      // Charger les stats depuis GitHub
      const [statsHistory, predictions] = await Promise.all([
        loadStatsHistory(),
        loadPredictions()
      ]);
      
      // Utiliser les stats pré-calculées si disponibles
      let stats = calculateStatsFromHistory(statsHistory, predictions);
      
      // Si pas de stats depuis GitHub, utiliser le store local
      if (!stats) {
        console.log('⚠️ Pas de stats_history sur GitHub, utilisation du store local');
        const detailedStats = PredictionStore.getDetailedStats();
        stats = detailedStats;
      }
      
      // Filtrer par sport si demandé
      if (sport && predictions?.predictions) {
        const filtered = predictions.predictions.filter((p: any) => p.sport === sport);
        stats = {
          daily: calculatePeriodStats(filtered.filter((p: any) => isToday(p.matchDate))),
          weekly: calculatePeriodStats(filtered.filter((p: any) => isThisWeek(p.matchDate))),
          monthly: calculatePeriodStats(filtered.filter((p: any) => isThisMonth(p.matchDate))),
          overall: calculatePeriodStats(filtered),
        };
      }
      
      const info = PredictionStore.getInfo();
      const integrity = PredictionStore.verifyIntegrity();
      
      return NextResponse.json({
        // Stats par période
        daily: stats?.daily || { totalPredictions: 0, completed: 0, wins: 0, losses: 0, winRate: 0 },
        weekly: stats?.weekly || { totalPredictions: 0, completed: 0, wins: 0, losses: 0, winRate: 0 },
        monthly: stats?.monthly || { totalPredictions: 0, completed: 0, wins: 0, losses: 0, winRate: 0 },
        overall: stats?.overall || { totalPredictions: 0, completed: 0, wins: 0, losses: 0, winRate: 0 },
        // Filtre actif
        filter: sport ? { sport } : null,
        // Infos générales
        ...info,
        // Intégrité
        integrity: integrity.valid,
        // Source des données
        source: statsHistory ? 'github_stats_history' : 'local_store',
        timestamp: new Date().toISOString()
      });
    }
    
    // Statistiques détaillées complètes
    if (action === 'detailed_stats') {
      const statsHistory = await loadStatsHistory();
      const predictions = await loadPredictions();
      const stats = calculateStatsFromHistory(statsHistory, predictions);
      
      if (stats) {
        return NextResponse.json(stats);
      }
      
      // Fallback sur store local
      const localStats = PredictionStore.getDetailedStats();
      return NextResponse.json(localStats);
    }
    
    // Historique des pronostics terminés
    if (action === 'history') {
      const predictions = await loadPredictions();
      const completed = predictions?.predictions?.filter((p: any) => p.status === 'completed') || [];
      return NextResponse.json({ predictions: completed });
    }
    
    // Pronostics en attente
    if (action === 'pending') {
      const predictions = await loadPredictions();
      const pending = predictions?.predictions?.filter((p: any) => p.status === 'pending') || [];
      return NextResponse.json({ predictions: pending });
    }
    
    // Tous les pronostics
    if (action === 'all') {
      const predictions = await loadPredictions();
      const statsHistory = await loadStatsHistory();
      const stats = calculateStatsFromHistory(statsHistory, predictions);
      return NextResponse.json({ 
        predictions: predictions?.predictions || [], 
        stats 
      });
    }
    
    // Vérifier l'intégrité
    if (action === 'verify') {
      const integrity = PredictionStore.verifyIntegrity();
      return NextResponse.json(integrity);
    }
    
    return NextResponse.json({ predictions: [] });
    
  } catch (error) {
    console.error('Erreur API results GET:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}

/**
 * POST - Actions: sauvegarder, vérifier les résultats, nettoyer
 */
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { action, predictions } = body;
    
    // Sauvegarder les pronostics du jour
    if (action === 'save_predictions') {
      if (!predictions || !Array.isArray(predictions)) {
        return NextResponse.json({ error: 'Données invalides' }, { status: 400 });
      }
      
      const saved = PredictionStore.addMany(predictions.map(p => ({
        matchId: p.matchId,
        homeTeam: p.homeTeam,
        awayTeam: p.awayTeam,
        league: p.league || 'Unknown',
        sport: p.sport || 'Foot',
        matchDate: p.matchDate || new Date().toISOString(),
        oddsHome: p.oddsHome,
        oddsDraw: p.oddsDraw || null,
        oddsAway: p.oddsAway,
        predictedResult: p.predictedResult,
        predictedGoals: p.predictedGoals,
        predictedCards: p.predictedCards,
        confidence: p.confidence || 'medium',
        riskPercentage: p.riskPercentage || 50
      })));
      
      return NextResponse.json({
        success: true,
        message: `${saved} nouveaux pronostics enregistrés`,
        saved
      });
    }
    
    // Vérifier les résultats d'hier
    if (action === 'check_results') {
      console.log('🔍 Vérification des résultats...');
      
      const realResults = await fetchYesterdayResults();
      
      if (realResults.length === 0) {
        return NextResponse.json({
          success: true,
          message: 'Aucun résultat disponible à vérifier',
          checked: 0,
          source: 'Football-Data API'
        });
      }
      
      const pendingPredictions = PredictionStore.getPending();
      
      let checkedCount = 0;
      let resultCorrect = 0;
      let goalsCorrect = 0;
      
      for (const prediction of pendingPredictions) {
        for (const realMatch of realResults) {
          const { found, homeScore, awayScore } = findMatchResult(
            realMatch, 
            prediction.homeTeam,
            prediction.awayTeam
          );
          
          if (found) {
            const actualResult = homeScore > awayScore ? 'home' 
              : homeScore < awayScore ? 'away' 
              : 'draw';
            
            const resultMatch = prediction.predictedResult === actualResult;
            if (resultMatch) resultCorrect++;
            
            let goalsMatch: boolean | undefined;
            
            if (prediction.predictedGoals) {
              const totalGoals = homeScore + awayScore;
              if (prediction.predictedGoals === 'over2.5') {
                goalsMatch = totalGoals > 2.5;
              } else if (prediction.predictedGoals === 'under2.5') {
                goalsMatch = totalGoals < 2.5;
              } else if (prediction.predictedGoals === 'btts') {
                goalsMatch = homeScore > 0 && awayScore > 0;
              }
              if (goalsMatch) goalsCorrect++;
            }
            
            PredictionStore.complete(prediction.matchId, {
              homeScore,
              awayScore,
              actualResult,
              resultMatch,
              goalsMatch
            });
            
            checkedCount++;
            console.log(`✅ ${prediction.homeTeam} ${homeScore}-${awayScore} ${prediction.awayTeam} - Résultat: ${resultMatch ? '✓' : '✗'}`);
            break;
          }
        }
      }
      
      // Récupérer les stats mises à jour
      const updatedStats = PredictionStore.getDetailedStats();
      
      return NextResponse.json({
        success: true,
        message: `${checkedCount} pronostics vérifiés`,
        checked: checkedCount,
        resultCorrect,
        goalsCorrect,
        source: 'Football-Data API',
        stats: updatedStats.daily
      });
    }
    
    // Nettoyer les anciennes données
    if (action === 'cleanup') {
      const removed = PredictionStore.cleanup();
      return NextResponse.json({
        success: true,
        message: `${removed} anciens pronostics supprimés`,
        removed
      });
    }
    
    // Supprimer toutes les données (reset complet)
    if (action === 'clear_all') {
      // Vérification de sécurité - nécessite un token
      const adminToken = body.token;
      const expectedToken = process.env.ADMIN_TOKEN || 'steo-admin-2026';
      
      if (adminToken !== expectedToken) {
        return NextResponse.json({ 
          error: 'Token administrateur requis' 
        }, { status: 403 });
      }
      
      const cleared = PredictionStore.clearAll();
      return NextResponse.json({
        success: cleared,
        message: cleared ? 'Toutes les données ont été supprimées' : 'Erreur lors de la suppression'
      });
    }
    
    return NextResponse.json({ error: 'Action non reconnue' }, { status: 400 });
    
  } catch (error) {
    console.error('Erreur API results POST:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
