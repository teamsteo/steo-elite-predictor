/**
 * Script de Mise à Jour des Statistiques
 * 
 * Calcule les stats à partir des prédictions completed
 * et met à jour stats_history.json
 */

import * as fs from 'fs';
import * as path from 'path';

const PREDICTIONS_FILE = path.join(process.cwd(), 'data/predictions.json');
const STATS_FILE = path.join(process.cwd(), 'data/stats_history.json');
const GITHUB_TOKEN = process.env.GITHUB_TOKEN;
const GITHUB_REPO = 'steohidy/my-project';

interface Prediction {
  matchId: string;
  homeTeam: string;
  awayTeam: string;
  sport: string;
  league: string;
  matchDate: string;
  predictedResult: string;
  predictedGoals?: string | null;
  status: 'pending' | 'completed';
  homeScore?: number;
  awayScore?: number;
  actualResult?: string;
  resultMatch?: boolean;
  goalsMatch?: boolean;
  checkedAt?: string;
}

// Grouper les prédictions par date
function groupByDate(predictions: Prediction[]): Map<string, Prediction[]> {
  const groups = new Map<string, Prediction[]>();
  
  for (const pred of predictions) {
    if (pred.status !== 'completed') continue;
    
    const date = pred.matchDate.split('T')[0];
    if (!groups.has(date)) {
      groups.set(date, []);
    }
    groups.get(date)!.push(pred);
  }
  
  return groups;
}

// Calculer les stats d'une journée
function calculateDayStats(predictions: Prediction[]): any {
  const completed = predictions.filter(p => p.status === 'completed');
  const wins = completed.filter(p => p.resultMatch === true).length;
  const losses = completed.filter(p => p.resultMatch === false).length;
  
  const withGoals = completed.filter(p => p.predictedGoals);
  const goalsCorrect = withGoals.filter(p => p.goalsMatch === true).length;
  
  const total = completed.length;
  const rate = total > 0 ? Math.round(wins / total * 100) : 0;
  const goalsRate = withGoals.length > 0 ? Math.round(goalsCorrect / withGoals.length * 100) : 0;
  
  return {
    stats: {
      results: { total, correct: wins, rate },
      goals: { total: withGoals.length, correct: goalsCorrect, rate: goalsRate },
      overall: Math.round((rate + goalsRate) / 2),
      completed: total,
      wins,
      losses,
      winRate: rate
    },
    predictions: completed.map(p => ({
      matchId: p.matchId,
      homeTeam: p.homeTeam,
      awayTeam: p.awayTeam,
      result: p.actualResult,
      prediction: p.predictedResult,
      correct: p.resultMatch,
      score: p.homeScore !== undefined ? `${p.homeScore}-${p.awayScore}` : undefined
    }))
  };
}

// Sauvegarder sur GitHub
async function saveToGitHub(content: string, filePath: string, message: string): Promise<boolean> {
  if (!GITHUB_TOKEN) {
    console.log('⚠️ GITHUB_TOKEN non configuré');
    return false;
  }
  
  try {
    // Get SHA
    const getRes = await fetch(
      `https://api.github.com/repos/${GITHUB_REPO}/contents/${filePath}`,
      {
        headers: {
          Authorization: `token ${GITHUB_TOKEN}`,
          Accept: 'application/vnd.github.v3+json'
        }
      }
    );
    
    let sha = '';
    if (getRes.ok) {
      const fileInfo = await getRes.json();
      sha = fileInfo.sha;
    }
    
    // Save
    const base64Content = Buffer.from(content).toString('base64');
    const saveRes = await fetch(
      `https://api.github.com/repos/${GITHUB_REPO}/contents/${filePath}`,
      {
        method: 'PUT',
        headers: {
          Authorization: `token ${GITHUB_TOKEN}`,
          Accept: 'application/vnd.github.v3+json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message,
          content: base64Content,
          sha: sha || undefined,
          branch: 'master'
        })
      }
    );
    
    return saveRes.ok;
  } catch (e) {
    console.error('Erreur GitHub:', e);
    return false;
  }
}

async function main() {
  console.log('📊 ==========================================');
  console.log('📊 MISE À JOUR DES STATISTIQUES');
  console.log(`📊 ${new Date().toLocaleString('fr-FR')}`);
  console.log('📊 ==========================================\n');
  
  if (!fs.existsSync(PREDICTIONS_FILE)) {
    console.log('❌ Fichier prédictions non trouvé');
    return;
  }
  
  const store = JSON.parse(fs.readFileSync(PREDICTIONS_FILE, 'utf-8'));
  const predictions: Prediction[] = store.predictions || [];
  
  console.log(`📊 ${predictions.length} prédictions chargées`);
  console.log(`📊 ${predictions.filter(p => p.status === 'completed').length} terminées\n`);
  
  // Grouper par date
  const byDate = groupByDate(predictions);
  console.log(`📅 ${byDate.size} jours avec des résultats\n`);
  
  // Charger les stats existantes
  let statsData: any = { dailyStats: [], version: '2.0' };
  if (fs.existsSync(STATS_FILE)) {
    statsData = JSON.parse(fs.readFileSync(STATS_FILE, 'utf-8'));
  }
  
  // Calculer les stats pour chaque jour
  let updated = 0;
  for (const [date, dayPredictions] of byDate) {
    const dayStats = calculateDayStats(dayPredictions);
    
    const existingIndex = statsData.dailyStats.findIndex((s: any) => s.date === date);
    const newEntry = {
      date,
      ...dayStats
    };
    
    if (existingIndex >= 0) {
      statsData.dailyStats[existingIndex] = newEntry;
    } else {
      statsData.dailyStats.push(newEntry);
    }
    updated++;
    
    console.log(`📅 ${date}: ${dayStats.stats.wins}/${dayStats.stats.completed} (${dayStats.stats.winRate}%)`);
  }
  
  // Trier par date (plus récent d'abord)
  statsData.dailyStats.sort((a: any, b: any) => b.date.localeCompare(a.date));
  
  // Garder 30 jours
  statsData.dailyStats = statsData.dailyStats.slice(0, 30);
  
  // Calculer les totaux
  const totalCompleted = statsData.dailyStats.reduce((sum: number, d: any) => sum + d.stats.completed, 0);
  const totalWins = statsData.dailyStats.reduce((sum: number, d: any) => sum + d.stats.wins, 0);
  
  statsData.summary = {
    totalDays: statsData.dailyStats.length,
    totalPredictions: totalCompleted,
    totalWins,
    totalLosses: totalCompleted - totalWins,
    overallWinRate: totalCompleted > 0 ? Math.round(totalWins / totalCompleted * 100) : 0,
    lastUpdated: new Date().toISOString()
  };
  
  // Sauvegarder localement
  fs.writeFileSync(STATS_FILE, JSON.stringify(statsData, null, 2));
  console.log(`\n✅ ${updated} jours mis à jour`);
  console.log(`📊 Total: ${totalWins}/${totalCompleted} (${statsData.summary.overallWinRate}%)`);
  
  // Sauvegarder sur GitHub
  if (GITHUB_TOKEN) {
    console.log('\n📤 Sauvegarde sur GitHub...');
    const saved = await saveToGitHub(
      JSON.stringify(statsData, null, 2),
      'data/stats_history.json',
      `📊 Stats mises à jour: ${totalWins}/${totalCompleted} (${statsData.summary.overallWinRate}%)`
    );
    console.log(saved ? '✅ Sauvegardé sur GitHub' : '❌ Erreur sauvegarde');
  }
  
  console.log('\n🎉 Terminé!');
}

main().catch(console.error);
