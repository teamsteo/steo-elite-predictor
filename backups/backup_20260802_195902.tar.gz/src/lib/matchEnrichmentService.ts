/**
 * Match Enrichment Service — Zero-Cost Data Enrichment
 *
 * All sources are 100% free, no API keys, no ban risk:
 * - Weather: Open-Meteo Geocoding + Forecast APIs
 * - Fatigue: Computed from match schedule dates
 * - Records: Parsed from ESPN record strings (e.g. "15-5-2")
 */

export interface MatchEnrichment {
  weather?: {
    temperature: number;
    precipitation: number;
    windSpeed: number;
    condition: string;
    impact: number; // -0.3 to +0.3 goals adjustment
    riskLevel: 'low' | 'medium' | 'high';
  };
  fatigue?: {
    homeDaysRest: number;
    awayDaysRest: number;
    homeIsBackToBack: boolean;
    awayIsBackToBack: boolean;
    homeFatigueScore: number; // 0-1, 0=rested, 1=exhausted
    awayFatigueScore: number;
    fatigueDifferential: number; // home - away, positive = home more rested
  };
  recordStrength?: {
    homeWinPct: number;
    awayWinPct: number;
    homeWinPctDiff: number; // home - away
    recordQuality: 'high' | 'medium' | 'low';
  };
}

interface EnrichmentInput {
  homeTeam: string;
  awayTeam: string;
  date: string; // ISO
  sport: string;
  league?: string;
  homeRecord?: string;
  awayRecord?: string;
  venue?: string;
  venueCity?: string;
  venueCountry?: string;
  homeRecentDates?: string[];
  awayRecentDates?: string[];
}

// ---- Caches (1h geo, 6h weather) ----

const geoCache = new Map<string, { data: { latitude: number; longitude: number }; ts: number }>();
const weatherCache = new Map<string, { data: MatchEnrichment['weather']; ts: number }>();
const GEO_TTL = 3_600_000;
const WEATHER_TTL = 21_600_000;

const WMO: Record<number, string> = {
  0: 'clear', 1: 'clear', 2: 'partly_cloudy', 3: 'cloudy',
  45: 'fog', 48: 'fog',
  51: 'drizzle', 53: 'drizzle', 55: 'drizzle', 56: 'drizzle', 57: 'drizzle',
  61: 'rain', 63: 'rain', 65: 'heavy_rain', 66: 'rain', 67: 'heavy_rain',
  71: 'snow', 73: 'snow', 75: 'snow', 77: 'snow',
  80: 'rain', 81: 'rain', 82: 'heavy_rain',
  85: 'snow', 86: 'snow',
  95: 'thunderstorm', 96: 'thunderstorm', 99: 'extreme',
};

// ---- 1. Dynamic Weather (Open-Meteo) ----

async function geocodeCity(city: string, country?: string) {
  const key = `${city.toLowerCase()}${country ? `_${country.toLowerCase()}` : ''}`;
  const c = geoCache.get(key);
  if (c && Date.now() - c.ts < GEO_TTL) return c.data;
  try {
    const p = new URLSearchParams({ name: city, count: '1', language: 'en', format: 'json' });
    const r = await fetch(`https://geocoding-api.open-meteo.com/v1/search?${p}`);
    if (!r.ok) return null;
    const j = (await r.json()) as { results?: { latitude: number; longitude: number }[] };
    const res = j.results?.[0];
    if (!res) return null;
    geoCache.set(key, { data: res, ts: Date.now() });
    return res;
  } catch { return null; }
}

async function fetchWeather(lat: number, lon: number, matchTime: Date) {
  const key = `${lat.toFixed(2)}_${lon.toFixed(2)}`;
  const c = weatherCache.get(key);
  if (c && Date.now() - c.ts < WEATHER_TTL) return c.data;
  try {
    const p = new URLSearchParams({
      latitude: String(lat), longitude: String(lon),
      hourly: 'temperature_2m,precipitation,windspeed_10m,weathercode',
      forecast_days: '3', timezone: 'auto',
    });
    const r = await fetch(`https://api.open-meteo.com/v1/forecast?${p}`);
    if (!r.ok) return null;
    const j = (await r.json()) as { hourly?: { time: string[]; temperature_2m: number[]; precipitation: number[]; windspeed_10m: number[]; weathercode: number[] } };
    const h = j.hourly;
    if (!h?.time?.length) return null;

    const matchMs = matchTime.getTime();
    let best = 0, bestDiff = Infinity;
    for (let i = 0; i < h.time.length; i++) {
      const d = Math.abs(new Date(h.time[i]).getTime() - matchMs);
      if (d < bestDiff) { bestDiff = d; best = i; }
    }

    const temp = h.temperature_2m[best] ?? 15;
    const precip = h.precipitation[best] ?? 0;
    const wind = h.windspeed_10m[best] ?? 0;
    const cond = WMO[h.weathercode[best] ?? 0] || 'clear';
    const { impact, riskLevel } = weatherImpact(temp, precip, wind, cond);

    const w: MatchEnrichment['weather'] = {
      temperature: Math.round(temp * 10) / 10,
      precipitation: Math.round(precip * 10) / 10,
      windSpeed: Math.round(wind * 10) / 10,
      condition: cond, impact, riskLevel,
    };
    weatherCache.set(key, { data: w, ts: Date.now() });
    return w;
  } catch { return null; }
}

function weatherImpact(temp: number, precip: number, wind: number, cond: string) {
  let impact = 0;
  let rl: 'low' | 'medium' | 'high' = 'low';

  if (precip > 5) { impact += 0.15; rl = 'high'; }
  else if (precip > 1) { impact += 0.1; rl = 'medium'; }
  else if (precip > 0) impact += 0.05;

  if (wind > 50) { impact -= 0.15; rl = 'high'; }
  else if (wind > 30) { impact -= 0.1; if (rl === 'low') rl = 'medium'; }

  if (temp < -5) { impact -= 0.2; rl = 'high'; }
  else if (temp < 0) { impact -= 0.1; if (rl === 'low') rl = 'medium'; }
  else if (temp > 35) { impact -= 0.15; rl = 'high'; }
  else if (temp > 30) { impact -= 0.08; if (rl === 'low') rl = 'medium'; }

  if (cond === 'thunderstorm' || cond === 'extreme') { impact = -0.3; rl = 'high'; }
  else if (cond === 'heavy_rain' || cond === 'snow') {
    impact = Math.max(impact, cond === 'snow' ? -0.2 : 0.15); rl = 'high';
  }

  return { impact: Math.round(Math.max(-0.3, Math.min(0.3, impact)) * 100) / 100, riskLevel: rl };
}

async function enrichWeather(m: EnrichmentInput): Promise<MatchEnrichment['weather'] | undefined> {
  if (!m.venueCity) return undefined;
  const geo = await geocodeCity(m.venueCity, m.venueCountry);
  if (!geo) return undefined;
  return (await fetchWeather(geo.latitude, geo.longitude, new Date(m.date))) ?? undefined;
}

// ---- 2. Fatigue / Rest Calculator ----

function daysSinceLast(matchISO: string, recent: string[]): number {
  if (!recent.length) return 14;
  const ms = new Date(matchISO).getTime();
  let closest = -Infinity;
  for (const d of recent) { const t = new Date(d).getTime(); if (t < ms && t > closest) closest = t; }
  if (closest === -Infinity) return 14;
  return Math.round(Math.max(0, Math.min(30, (ms - closest) / 86400000)));
}

function isB2B(matchISO: string, recent: string[]): boolean {
  if (!recent.length) return false;
  const ms = new Date(matchISO).getTime();
  return recent.some(d => { const diff = ms - new Date(d).getTime(); return diff > 0 && diff <= 86400000; });
}

function fatigueScore(daysRest: number, b2b: boolean, isAway: boolean): number {
  let s = 1 - Math.min(1, daysRest / 7);
  if (b2b) s = Math.min(1, s + 0.3);
  if (isAway) s = Math.min(1, s + 0.04);
  return Math.round(Math.max(0, Math.min(1, s)) * 1000) / 1000;
}

function enrichFatigue(m: EnrichmentInput): MatchEnrichment['fatigue'] {
  const hd = m.homeRecentDates || [], ad = m.awayRecentDates || [];
  const hRest = daysSinceLast(m.date, hd), aRest = daysSinceLast(m.date, ad);
  const hB2B = isB2B(m.date, hd), aB2B = isB2B(m.date, ad);
  const hf = fatigueScore(hRest, hB2B, false), af = fatigueScore(aRest, aB2B, true);
  return {
    homeDaysRest: hRest, awayDaysRest: aRest,
    homeIsBackToBack: hB2B, awayIsBackToBack: aB2B,
    homeFatigueScore: hf, awayFatigueScore: af,
    fatigueDifferential: Math.round((hf - af) * 1000) / 1000,
  };
}

// ---- 3. Record / Strength Features ----

function parseRecord(rec: string | undefined): { wins: number; losses: number; ties: number } | null {
  if (!rec) return null;
  const p = rec.trim().split('-');
  if (p.length < 2) return null;
  const w = parseInt(p[0], 10), l = parseInt(p[1], 10), t = p.length >= 3 ? parseInt(p[2], 10) : 0;
  if (isNaN(w) || isNaN(l) || isNaN(t) || w < 0 || l < 0 || t < 0) return null;
  return { wins: w, losses: l, ties: t };
}

function winPct(r: { wins: number; losses: number; ties: number }): number {
  const total = r.wins + r.losses + r.ties;
  if (!total) return 0.5;
  return Math.round(((r.wins + r.ties * 0.5) / total) * 1000) / 1000;
}

function enrichRecordStrength(m: EnrichmentInput): MatchEnrichment['recordStrength'] | undefined {
  const hp = parseRecord(m.homeRecord), ap = parseRecord(m.awayRecord);
  if (!hp && !ap) return undefined;
  const hw = hp ? winPct(hp) : 0.5, aw = ap ? winPct(ap) : 0.5;
  const totalGames = (hp?.wins ?? 0) + (hp?.losses ?? 0) + (hp?.ties ?? 0)
    + (ap?.wins ?? 0) + (ap?.losses ?? 0) + (ap?.ties ?? 0);
  return {
    homeWinPct: hw, awayWinPct: aw,
    homeWinPctDiff: Math.round((hw - aw) * 1000) / 1000,
    recordQuality: totalGames >= 40 ? 'high' : totalGames >= 15 ? 'medium' : 'low',
  };
}

// ---- 4. Main Enrichment ----

/**
 * Enrich a match with zero-cost data: weather, fatigue, record strength.
 * Each enrichment is independent — failures return partial data, never throws.
 */
export async function enrichMatch(match: EnrichmentInput): Promise<MatchEnrichment> {
  const result: MatchEnrichment = {};

  try {
    const w = await enrichWeather(match);
    if (w) result.weather = w;
  } catch (e) { console.warn('[enrichMatch] weather failed:', e); }

  try { result.fatigue = enrichFatigue(match); } catch (e) { console.warn('[enrichMatch] fatigue failed:', e); }

  try { const r = enrichRecordStrength(match); if (r) result.recordStrength = r; } catch (e) { console.warn('[enrichMatch] records failed:', e); }

  return result;
}

/** Clear all enrichment caches. */
export function clearEnrichmentCaches(): void { geoCache.clear(); weatherCache.clear(); }
