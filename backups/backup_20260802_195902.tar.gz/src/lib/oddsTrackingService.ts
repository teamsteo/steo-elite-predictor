/**
 * Odds Tracking Service — Zero-Cost Live Odds Tracking
 *
 * Uses ONLY ESPN data already fetched by combinedDataService.ts.
 * Tracks odds movements over time in Supabase to detect:
 * - Steam moves (sharp money causing rapid line changes)
 * - CLV (Closing Line Value) in real-time
 * - Market consensus shifts
 *
 * NO external API calls — all data comes from existing ESPN fetches.
 * Storage: Supabase `odds_history` table.
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';

// ============================================
// TYPES
// ============================================

export interface OddsSnapshot {
  matchId: string;
  oddsHome: number;
  oddsDraw: number | null;
  oddsAway: number;
  oddsSource: string;
  snapshotTime: string;
}

export interface SteamMove {
  matchId: string;
  homeTeam: string;
  awayTeam: string;
  sport: string;
  direction: 'home' | 'away';
  oldOdds: number;
  newOdds: number;
  changePercent: number;
  timeSpan: number; // minutes
  severity: 'moderate' | 'significant' | 'steam';
}

export interface CLVAnalysis {
  matchId: string;
  openingOdds: number | null;
  currentOdds: number;
  clv: number | null;
  clvDirection: 'favorable' | 'unfavorable' | 'neutral' | 'no_opening';
  movePercent: number | null;
}

interface SnapshotRow {
  id?: string;
  match_id: string;
  sport: string;
  home_team?: string;
  away_team?: string;
  odds_home: number;
  odds_draw: number | null;
  odds_away: number;
  odds_source: string;
  snapshot_time: string;
  is_estimated: boolean;
}

// ============================================
// SUPABASE CLIENT (lazy)
// ============================================

let _sb: SupabaseClient | null = null;
function getSB(): SupabaseClient | null {
  if (_sb) return _sb;
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) return null;
  try {
    _sb = createClient(url, key);
    return _sb;
  } catch {
    return null;
  }
}

// ============================================
// 1. SAVE SNAPSHOTS
// ============================================

/**
 * Save a batch of odds snapshots. Skips if odds unchanged from last snapshot.
 * Max 5 snapshots per match per day to prevent excessive storage.
 */
export async function saveOddsSnapshots(
  matches: Array<{
    id: string; homeTeam: string; awayTeam: string; sport: string;
    oddsHome: number; oddsDraw: number | null; oddsAway: number;
    oddsSource: string; isEstimated: boolean;
  }>
): Promise<{ saved: number; errors: number }> {
  const sb = getSB();
  if (!sb) return { saved: 0, errors: 0 };

  let saved = 0, errors = 0;
  const now = new Date().toISOString();

  for (const m of matches) {
    try {
      // Check last snapshot for this match
      const { data: last } = await sb
        .from('odds_history')
        .select('odds_home, odds_away, odds_draw')
        .eq('match_id', m.id)
        .order('snapshot_time', { ascending: false })
        .limit(1);

      // Skip if odds unchanged (within 0.01 tolerance)
      if (last && last.length > 0) {
        const prev = last[0];
        if (Math.abs(prev.odds_home - m.oddsHome) < 0.01 &&
            Math.abs(prev.odds_away - m.oddsAway) < 0.01) {
          continue; // No change, skip
        }
      }

      // Check daily count
      const todayStart = new Date();
      todayStart.setUTCHours(0, 0, 0, 0);
      const { count } = await sb
        .from('odds_history')
        .select('*', { count: 'exact', head: true })
        .eq('match_id', m.id)
        .gte('snapshot_time', todayStart.toISOString());

      if ((count || 0) >= 5) continue; // Max 5 per day

      // Insert new snapshot
      const row: SnapshotRow = {
        match_id: m.id,
        sport: m.sport,
        home_team: m.homeTeam,
        away_team: m.awayTeam,
        odds_home: m.oddsHome,
        odds_draw: m.oddsDraw,
        odds_away: m.oddsAway,
        odds_source: m.oddsSource,
        snapshot_time: now,
        is_estimated: m.isEstimated,
      };

      const { error } = await sb.from('odds_history').insert(row);
      if (!error) saved++;
      else errors++;
    } catch {
      errors++;
    }
  }

  return { saved, errors };
}

// ============================================
// 2. GET HISTORY
// ============================================

export async function getOddsHistory(matchId: string): Promise<OddsSnapshot[]> {
  const sb = getSB();
  if (!sb) return [];

  try {
    const { data, error } = await sb
      .from('odds_history')
      .select('match_id, odds_home, odds_draw, odds_away, odds_source, snapshot_time')
      .eq('match_id', matchId)
      .order('snapshot_time', { ascending: true });

    if (error || !data) return [];

    return (data as any[]).map((r: any) => ({
      matchId: r.match_id,
      oddsHome: r.odds_home,
      oddsDraw: r.odds_draw,
      oddsAway: r.odds_away,
      oddsSource: r.odds_source,
      snapshotTime: r.snapshot_time,
    }));
  } catch {
    return [];
  }
}

// ============================================
// 3. DETECT STEAM MOVES
// ============================================

/**
 * Detect significant odds changes (steam moves) in the last 6 hours.
 * A steam move indicates sharp money hitting one side.
 */
export async function detectSteamMoves(sport?: string): Promise<SteamMove[]> {
  const sb = getSB();
  if (!sb) return [];

  try {
    const cutoff = new Date();
    cutoff.setHours(cutoff.getHours() - 6);

    // Get matches with 2+ snapshots in last 6 hours
    const query = sb
      .from('odds_history')
      .select('match_id, home_team, away_team, sport, odds_home, odds_away, snapshot_time')
      .gte('snapshot_time', cutoff.toISOString())
      .order('match_id', { ascending: true })
      .order('snapshot_time', { ascending: true });

    if (sport) query.eq('sport', sport);

    const { data, error } = await query;
    if (error || !data) return [];

    const rows = data as any[];
    const grouped = new Map<string, any[]>();
    for (const r of rows) {
      const g = grouped.get(r.match_id) || [];
      g.push(r);
      grouped.set(r.match_id, g);
    }

    const moves: SteamMove[] = [];
    for (const [, snapshots] of grouped) {
      if (snapshots.length < 2) continue;

      const first = snapshots[0];
      const last = snapshots[snapshots.length - 1];

      // Check home odds movement
      const homeChange = ((last.odds_home - first.odds_home) / first.odds_home) * 100;
      const awayChange = ((last.odds_away - first.odds_away) / first.odds_away) * 100;

      const timeSpan = (new Date(last.snapshot_time).getTime() -
                        new Date(first.snapshot_time).getTime()) / 60000;

      // Determine which side moved
      const absHome = Math.abs(homeChange);
      const absAway = Math.abs(awayChange);

      if (absHome >= 3 || absAway >= 3) {
        const direction = absHome >= absAway ? 'home' : 'away';
        const changePct = direction === 'home' ? homeChange : awayChange;
        const oldOdds = direction === 'home' ? first.odds_home : first.odds_away;
        const newOdds = direction === 'home' ? last.odds_home : last.odds_away;

        // Odds dropping = money on that side (direction indicates where bets are going)
        // Negative change = odds dropped = that side is being backed
        const isBacking = changePct < 0;

        moves.push({
          matchId: first.match_id,
          homeTeam: first.home_team || '',
          awayTeam: first.away_team || '',
          sport: first.sport || '',
          direction,
          oldOdds,
          newOdds,
          changePercent: Math.abs(changePct),
          timeSpan,
          severity: Math.abs(changePct) >= 8 ? 'steam'
               : Math.abs(changePct) >= 5 ? 'significant'
               : 'moderate',
        });
      }
    }

    return moves.sort((a, b) => b.changePercent - a.changePercent);
  } catch {
    return [];
  }
}

// ============================================
// 4. CALCULATE LIVE CLV
// ============================================

/**
 * Calculate Closing Line Value for current matches.
 * Compares today's opening odds (first snapshot) with current odds.
 * Positive CLV = market moved in our predicted direction.
 */
export async function calculateLiveCLV(
  matches: Array<{ id: string; oddsHome: number; oddsAway: number; predictedResult?: string }>
): Promise<CLVAnalysis[]> {
  const sb = getSB();
  if (!sb) return [];

  try {
    const todayStart = new Date();
    todayStart.setUTCHours(0, 0, 0, 0);

    const results: CLVAnalysis[] = [];

    for (const m of matches) {
      const { data: snapshots } = await sb
        .from('odds_history')
        .select('odds_home, odds_away')
        .eq('match_id', m.id)
        .gte('snapshot_time', todayStart.toISOString())
        .order('snapshot_time', { ascending: true })
        .limit(1);

      if (!snapshots || snapshots.length === 0) {
        results.push({
          matchId: m.id,
          openingOdds: null,
          currentOdds: m.predictedResult === 'home' ? m.oddsHome : m.oddsAway,
          clv: null,
          clvDirection: 'no_opening',
          movePercent: null,
        });
        continue;
      }

      const opening = snapshots[0] as any;
      const openingOdds = m.predictedResult === 'home' ? opening.odds_home : opening.odds_away;
      const currentOdds = m.predictedResult === 'home' ? m.oddsHome : m.oddsAway;

      if (!openingOdds || openingOdds <= 0) {
        results.push({
          matchId: m.id,
          openingOdds: null,
          currentOdds,
          clv: null,
          clvDirection: 'no_opening',
          movePercent: null,
        });
        continue;
      }

      // CLV: positive = odds dropped on our pick = market agrees = good
      const movePct = ((currentOdds - openingOdds) / openingOdds) * 100;
      const clv = -movePct; // Negative move = odds dropped = value for us

      results.push({
        matchId: m.id,
        openingOdds,
        currentOdds,
        clv: Math.round(clv * 100) / 100,
        clvDirection: clv > 2 ? 'favorable' : clv < -2 ? 'unfavorable' : 'neutral',
        movePercent: Math.round(movePct * 100) / 100,
      });
    }

    return results;
  } catch {
    return [];
  }
}

// ============================================
// 5. CLEANUP
// ============================================

/**
 * Delete snapshots older than 7 days to prevent table bloat.
 */
export async function cleanupOldSnapshots(): Promise<number> {
  const sb = getSB();
  if (!sb) return 0;

  try {
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - 7);

    const { data, error } = await sb
      .from('odds_history')
      .select('id')
      .lt('snapshot_time', cutoff.toISOString())
      .limit(10000);

    if (error || !data || data.length === 0) return 0;

    const ids = data.map((r: any) => r.id).filter(Boolean);
    const { error: delError } = await sb
      .from('odds_history')
      .delete()
      .in('id', ids);

    return delError ? 0 : ids.length;
  } catch {
    return 0;
  }
}

// ============================================
// 6. CRON INTEGRATION HELPER
// ============================================

/**
 * Called by cron after getMatchesWithRealOdds().
 * Tracks odds changes, detects steam moves, and calculates CLV.
 */
export async function trackOddsForToday(matches: any[]): Promise<{
  saved: number;
  steamMoves: SteamMove[];
  clvAnalysis: CLVAnalysis[];
}> {
  // 1. Save snapshots (non-blocking, best-effort)
  const { saved } = await saveOddsSnapshots(
    matches.filter((m: any) => m.hasRealOdds && !m.isEstimated).map((m: any) => ({
      id: m.id,
      homeTeam: m.homeTeam,
      awayTeam: m.awayTeam,
      sport: m.sport,
      oddsHome: m.oddsHome,
      oddsDraw: m.oddsDraw ?? null,
      oddsAway: m.oddsAway,
      oddsSource: m.oddsSource || 'espn',
      isEstimated: m.isEstimated || false,
    }))
  );

  // 2. Detect steam moves
  const steamMoves = await detectSteamMoves();

  // 3. Calculate CLV for current predictions
  const clvAnalysis = await calculateLiveCLV(
    matches.filter((m: any) => m.predictedResult).map((m: any) => ({
      id: m.id,
      oddsHome: m.oddsHome,
      oddsAway: m.oddsAway,
      predictedResult: m.predictedResult,
    }))
  );

  if (saved > 0) {
    console.log(`📊 Odds tracking: ${saved} snapshots saved, ${steamMoves.length} steam moves, ${clvAnalysis.length} CLV analyses`);
  }

  return { saved, steamMoves, clvAnalysis };
}

// ============================================
// SQL SCHEMA (for reference — run manually)
// ============================================
/*
CREATE TABLE IF NOT EXISTS odds_history (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  match_id TEXT NOT NULL,
  sport TEXT NOT NULL,
  home_team TEXT,
  away_team TEXT,
  odds_home DECIMAL(6,3),
  odds_draw DECIMAL(6,3),
  odds_away DECIMAL(6,3),
  odds_source TEXT,
  snapshot_time TIMESTAMPTZ DEFAULT NOW(),
  is_estimated BOOLEAN DEFAULT FALSE
);

-- Index for fast lookups
CREATE INDEX idx_odds_history_match_id ON odds_history(match_id);
CREATE INDEX idx_odds_history_snapshot_time ON odds_history(snapshot_time);
CREATE INDEX idx_odds_history_sport ON odds_history(sport);
*/
